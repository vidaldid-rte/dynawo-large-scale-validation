
About how case files are produced
---------------------------------

   * The *DynaWaltz* cases we use are produced in RTE's platform
     called "CONVERGENCE"

   * In contrast, the *DynaFlow* cases we use are produced by a
     different tool, called "DynaFlow Launcher".  This is why the file
     layout, file naming conventions, etc., are different.
